﻿using System;
using Assets.Scripts.Game;
using Assets.Scripts.Helper;
using NetworkCommsDotNet;
using NetworkCommsDotNet.Connections.TCP;
using TStuff.Game.TowerDefense3d.lib;
using TStuff.Game.TowerDefense3d.lib.ContractObjects;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts.Network
{
    public class NetLogin : MonoBehaviour
    {

        public GameObject InputUserName;
        public GameObject InputIp;
        public GameObject InputPort;
        public GameObject TextConnectionInfo;
        public GameObject ButtonConnect;
        public GameObject ButtonDisconnect;

        private NetworkClient _nClient;
        private Login _loginToUse;
        public GamePlayerInfo _info;

        // Use this for initialization
        void Start ()
        {
            _info = GameObject.Find("GlobalEvents").GetComponent<GamePlayerInfo>();
            _nClient = GameObject.Find("ServerConnection").GetComponent<NetworkClient>();
            NetworkComms.AppendGlobalIncomingPacketHandler<Login>(RequestNames.Login, (header, connection, incomingObject) =>
            {
                _loginToUse = incomingObject;
                Debug.Log("My ID: " + _loginToUse.Id);
                _info.SetLoginData(incomingObject);
                UnityMainThreadDispatcher.Instance().Enqueue(SetConnectionInfo);

            });
        }
	
        // Update is called once per frame
        void Update () {
		
        }

        public void Disconnect()
        {
            TextConnectionInfo.GetComponent<Text>().text = "Disconnected";
            TextConnectionInfo.GetComponent<Text>().color = Color.yellow;
            InputUserName.GetComponent<InputField>().interactable = true;
            InputIp.GetComponent<InputField>().interactable = true;
            InputPort.GetComponent<InputField>().interactable = true;
            ButtonConnect.GetComponent<Button>().interactable = true;
            ButtonDisconnect.GetComponent<Button>().interactable = false;
            _nClient.Disconnect();
        }

        public void SetConnectionInfo()
        {

            TextConnectionInfo.GetComponent<Text>().text = "Connected as " + PlayerPrefs.GetString("name");
            TextConnectionInfo.GetComponent<Text>().color = Color.green;

            InputUserName.GetComponent<InputField>().interactable = false;
            InputIp.GetComponent<InputField>().interactable = false;
            InputPort.GetComponent<InputField>().interactable = false;
            ButtonConnect.GetComponent<Button>().interactable = false;
            ButtonDisconnect.GetComponent<Button>().interactable = true;

        }

        public void SendLogin(string name, string ip, string port)
        {
            try
            {
                PlayerPrefs.SetString("name", name);
                PlayerPrefs.SetString("ip", ip);
                PlayerPrefs.SetString("port", port);
                Debug.Log("Start NetworkClient");
                _nClient.Connection = TCPConnection.GetConnection(new ConnectionInfo(ip, int.Parse(port)));
                Debug.Log("Start Connection");
                _nClient.Connection.SendObject<Login>("login", new Login {Name = name});
                Debug.Log("Send login");
            }
            catch (ConnectionSetupException ex)
            {
                TextConnectionInfo.GetComponent<Text>().text = "Cant connect to Server: " + ip + ":" + port;
                TextConnectionInfo.GetComponent<Text>().color = Color.red;
                _nClient.Disconnect();
                throw ex;
            }
            catch (Exception ex)
            {
                Debug.LogWarning(ex.Message); 
            }
        
        }

        public void TryConnect()
        {

            if (PlayerPrefs.GetString("name") != null && PlayerPrefs.GetString("ip") != null && PlayerPrefs.GetString("port") != null)
            {
                var username = PlayerPrefs.GetString("name");
                var serverIp = PlayerPrefs.GetString("ip");
                var port = PlayerPrefs.GetString("port");
                SendLogin(username, serverIp, port);
            }


        }
    }
}
