﻿using System;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Game;
using Assets.Scripts.MapBuild;
using Assets.Scripts.UI;
using NetworkCommsDotNet;
using NetworkCommsDotNet.Connections;
using NetworkCommsDotNet.DPSBase;
using TStuff.Game.TowerDefense3d.lib;
using TStuff.Game.TowerDefense3d.lib.ContractObjects;
using TStuff.Game.TowerDefense3d.lib.Enums;
using UnityEngine;

namespace Assets.Scripts.Network
{
    public class NetworkClient : MonoBehaviour
    {

        public Connection Connection;

        private int _number = 0;

        private GameCreateUi _mapList;
        private GameJoinUi _openGameInfo;
        private GeneralUi _generalUi;
        public GameObject GlobalEvents;
        public GameObject GameCreateUi;
        public GameObject MapGenerator;
        private MenueEvents _menueEvents;
        private MapBuilder _mapGenerator;
        private GlobalEvents _globalEvents;
        private MobRenderer _mobRenderer;
        private GameUiInfoUpdater _gameDataInfo;
        private GamePlayerInfo _generalGameData;
        private TowerRenderer _towerRenderer;

        // Use this for initialization
        void Start () {
            AddListeners();
            _mapList = GameCreateUi.GetComponent<GameCreateUi>();
            _openGameInfo = GameCreateUi.GetComponent<GameJoinUi>();
            _generalUi = GameCreateUi.GetComponent<GeneralUi>();
            _menueEvents = GameCreateUi.GetComponent<MenueEvents>();
            _mapGenerator = MapGenerator.GetComponent<MapBuilder>();
            _globalEvents = GlobalEvents.GetComponent<GlobalEvents>();
            _mobRenderer = MapGenerator.GetComponent<MobRenderer>();
            _gameDataInfo = GameCreateUi.GetComponent<GameUiInfoUpdater>();
            _generalGameData = GlobalEvents.GetComponent<GamePlayerInfo>();
            _towerRenderer = MapGenerator.GetComponent<TowerRenderer>();
            NetworkComms.DisableLogging();
        }


        private void AddListeners()
        {

            DataSerializer ds = DPSManager.GetDataSerializer<ProtobufSerializer>();
            NetworkComms.DefaultSendReceiveOptions = new SendReceiveOptions(ds, new List<DataProcessor>(), new Dictionary<string, string>());
            NetworkComms.AppendGlobalConnectionEstablishHandler(connection =>
            {
                Console.WriteLine("Icomming connection");
            });

            NetworkComms.AppendGlobalIncomingPacketHandler<ClientMessage>(RequestNames.Message,
                (header, connection, incomingObject) =>
                {
                    _generalUi.Messages.Enqueue(incomingObject);
                });

            NetworkComms.AppendGlobalIncomingPacketHandler<JoinGame>(RequestNames.GameJoinInfo,
                (header, connection, incomingObject) =>
                {
                    _openGameInfo.JoinGameObj = incomingObject;
                    _openGameInfo.IsPlayerListChanged = true;
                    _generalGameData.SetJoinData(incomingObject);

                } );

            NetworkComms.AppendGlobalIncomingPacketHandler<RaceModels>(RequestNames.GetObjectDb,
                (header, connection, incomingObject) =>
                {
                    _generalGameData.MobRaces = incomingObject.MobRaces.ToList();
                    _generalGameData.TowerRaces = incomingObject.TowerRaces.ToList();
                });

            NetworkComms.AppendGlobalIncomingPacketHandler<FastUpdate>(RequestNames.FastUpdate,
                (header, connection, incomingObject) =>
                {
                    try
                    {
                  
                  
                        if (incomingObject.Mobs != null)
                            _mobRenderer.MoveMobs = incomingObject.Mobs.ToList();
                        if(incomingObject.Tower != null)
                            _towerRenderer.TowerState = incomingObject.Tower.ToList();
                        // Debug.Log(incomingObject.Mobs[0].X);
                        _mobRenderer.UpdateMobs = true;
                        _towerRenderer.UpdateRequired = true;
                    }
                    catch (Exception ex)
                    {
                        Debug.Log(ex);
                    }


                } );
       
            NetworkComms.AppendGlobalIncomingPacketHandler<MapSelectList>(RequestNames.GetMapList,
                (header, connection, incomingObject) =>
                {
                    Debug.Log("Request: Map Count:  "+incomingObject.Maps.Length);
                
                    // UnityMainThreadDispatcher.Instance().Enqueue(SetMapInfo);
                    _mapList.MapList = incomingObject;
                    _mapList.MapListChanged = true;
                } );

            NetworkComms.AppendGlobalIncomingPacketHandler<OpenGameInfo[]>(RequestNames.GetOpenGames,
                (header, connection, incomingObject) =>
                {
                    _openGameInfo.OpenGameList = incomingObject.ToList();
                    _openGameInfo.IsGameListChanged = true;
                    // UnityMainThreadDispatcher.Instance().Enqueue(SetMapInfo);

                });

            NetworkComms.AppendGlobalIncomingPacketHandler<GameNotifications>(RequestNames.GameNotification,
                (header, connection, incomingObject) =>
                {
                    switch(incomingObject.Notification)
                    {
                        case GameNotificationType.GameCanceled:
                            _mobRenderer.Clear();
                            _towerRenderer.Clear();
                            _gameDataInfo.IsUpdateNeeded = false;
                            _globalEvents.LeaveGame();
                            _menueEvents.ResetGameWindow = true;
                            _openGameInfo.JoinGameObj = null;
                            _openGameInfo.IsPlayerListChanged = false;
                            _gameDataInfo.Info = null;
                            _mapGenerator.IsGameCanceled = true;

                            Debug.Log("Game was Canceled");
                            break;
                        case GameNotificationType.LeaveGame:
                            
                            break;
                        case GameNotificationType.Ready:
                            break;
                        case GameNotificationType.ChangeTeam:
                            break;
                        case GameNotificationType.StartGame:
                            
                            break;
                        default:
                            throw new ArgumentOutOfRangeException();
                    }
                });

            NetworkComms.AppendGlobalIncomingPacketHandler<MapDataModel>(RequestNames.GetMapData,
                (header, connection, incomingObject) =>
                {

                    _globalEvents.StartGame();
                    _mapGenerator.Model = incomingObject;
               
                });

            NetworkComms.AppendGlobalIncomingPacketHandler<GameInfoData>(RequestNames.GameDataInfo,
                (header, connection, incomingObject) =>
                {
                    _gameDataInfo.Info = incomingObject;
                    _gameDataInfo.IsUpdateNeeded = true;
                
                });
            NetworkComms.AppendGlobalIncomingPacketHandler<MapTowers>(RequestNames.TowerBuild,
                (header, connection, incomingObject) =>
                {
                    _towerRenderer.TowersToBuild.Push(incomingObject);
                });
            NetworkComms.AppendGlobalIncomingPacketHandler<MapTowers>(RequestNames.TowerRemove,
                (header, connection, incomingObject) =>
                {
                    _towerRenderer.TowersToRemove.Push(incomingObject);
                });
            NetworkComms.AppendGlobalIncomingPacketHandler<RaceModels>(RequestNames.GetObjectDb,
                (header, connection, incomingObject) =>
                {
                    Debug.Log("Get Game DB Items");
                    _generalGameData.SetTowerMobData(incomingObject);
                } );

        }
        public void BuildTower(int id,int x, int y)
        {
            Connection.SendObject(RequestNames.GameCommand, new GameCommands { Id = id, Command = GameCommand.BuildTower, X = x,Y = y});
        }

        public void SendMob(int id)
        {
            Connection.SendObject(RequestNames.GameCommand,new GameCommands{Id = id,Command = GameCommand.SendMob,IntVal = _generalGameData.MyTeamId==0?1:0});
        }
        public void RequestMapCreateGameInfo()
        {
            Connection.SendObject(RequestNames.GetMapInfos,new MapRequests{Request = MapRequestTypes.GetAllMaps});
        }
        // Update is called once per frame
        public void SendEcho(string message)
        {
            _number++;
            Connection.SendObject<EchoObject>("echo",new EchoObject{Id = _number,Message = message});
        }


        public void AutoLogin()
        {
            gameObject.GetComponent<NetLogin>().TryConnect();
        }

        public void CreateGame(GameSettings gameSettings)
        {
            Connection.SendObject(RequestNames.StartGame,gameSettings);
        }

        public void LeaveGame()
        {
            Connection.SendObject(RequestNames.GameNotification,new GameNotifications{Notification = GameNotificationType.LeaveGame});
        }

        public void RequestOpenGames()
        {
            Connection.SendObject(RequestNames.GetMapInfos, new MapRequests { Request = MapRequestTypes.GetOpenGames });
        }

        public void JoinGame(int id)
        {
            Connection.SendObject(RequestNames.JoinGame,new JoinGame{GameId = id});
        }

        public void Disconnect()
        {
            if (Connection != null)
            {
                Connection.Dispose();
                Connection = null;
            }
        }
    }
}
