﻿using System.Collections;
using System.Collections.Generic;
using Assets.Scripts.Network;
using UnityEngine;

namespace Assets.Scripts.Helper
{
    public class MouseSelector : MonoBehaviour
    {

        public GameObject PointerImage;
        public GameObject TowerBuildPreFab;
        public GameObject ObjectCam;

        private MouseMode _selectedMode;
        private NetworkClient _networkClient;
        private int _towerId;
        private bool _isReleased = true;
        private Vector3 _objectCamDefaultPos = new Vector3(0,1,-3.5f);
        private float _objectCamWorldHeight = 11f;
        private bool _isWorldView;

        // Use this for initialization
        void Start ()
        {
            _networkClient = GameObject.Find("ServerConnection").GetComponent<NetworkClient>();
            // PointerImage.GetComponent<Renderer>().enabled = false;
        }

        public void SetTowerBuild(int id)
        {
            _selectedMode = MouseMode.BuildTower;
            _towerId = id;
            // PointerImage.GetComponent<Renderer>().enabled = true;
       
        }

        public void SetTowerPreFab(string Name)
        {
        
        }
	
        // Update is called once per frame
        void Update ()
        {
            if (_isWorldView)
            {
                ObjectCam.transform.position = new Vector3(Camera.main.transform.position.x, _objectCamWorldHeight, Camera.main.transform.position.z);
                ObjectCam.transform.rotation = Quaternion.Euler(new Vector3(90, 0, 0));
                ObjectCam.transform.SetParent(null);
            }

            if (Input.GetKey(KeyCode.Escape))
            {
                SetNonMode();
            }

            RaycastHit hit;
            var ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out hit))
            {
                if (_selectedMode == MouseMode.BuildTower)
                {
                    PointerImage.transform.position = new Vector3(Mathf.Round(hit.point.x),0.5f,Mathf.Round(hit.point.z));
                
	            
                }

                if (Input.GetKey(KeyCode.Mouse0) && _isReleased)
                {
	          
                    if (hit.transform.tag == "Mob")
                    {
                        ObjectCam.transform.SetParent(hit.transform);
                        ObjectCam.transform.localPosition = _objectCamDefaultPos;
                        ObjectCam.transform.rotation = Quaternion.Euler(new Vector3(20, 0, 0));
                        _isWorldView = false;
                    }else if (hit.transform.tag == "Tower")
                    {
                        ObjectCam.transform.SetParent(hit.transform);
                        ObjectCam.transform.localPosition = _objectCamDefaultPos;
                        ObjectCam.transform.rotation = Quaternion.Euler(new Vector3(20, 0, 0));
                        _isWorldView = false;
                    }
                    else
                
                    if (hit.transform.gameObject.tag == ("Floor") && _selectedMode == MouseMode.Node)
                    {
                        _isWorldView = true;
	                
                    }
                    if (hit.transform.gameObject.tag == ("Floor") && _selectedMode == MouseMode.BuildTower)
                    {
                        _networkClient.BuildTower(_towerId, (int) Mathf.Round(hit.point.x), (int) Mathf.Round(hit.point.z));
                    }
                    _isReleased = false;

                    if (!Input.GetKey(KeyCode.LeftShift))
                        SetNonMode();
                }

                if (Input.GetKeyUp(KeyCode.Mouse0))
                {
                    _isReleased = true;
                }
            }
        
        }

        private void SetNonMode()
        {
            _selectedMode = MouseMode.Node;
            PointerImage.transform.SetPositionAndRotation(new Vector3(1,-1,1),Quaternion.identity );
            // PointerImage.GetComponent<Renderer>().enabled = false;
        }
    }
}