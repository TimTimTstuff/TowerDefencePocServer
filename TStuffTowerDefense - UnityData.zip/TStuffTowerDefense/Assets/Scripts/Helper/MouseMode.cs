﻿namespace Assets.Scripts.Helper
{
    public enum MouseMode
    {
        Node,
        BuildTower
    }
}