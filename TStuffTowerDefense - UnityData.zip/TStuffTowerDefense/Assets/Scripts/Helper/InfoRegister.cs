﻿using System.Collections;
using System.Collections.Generic;
using TStuff.Game.TowerDefense3d.lib.ContractObjects;
using UnityEngine;

public class InfoRegister : MonoBehaviour
{

    public MobData Mob;
    public TowerData TowerData;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
