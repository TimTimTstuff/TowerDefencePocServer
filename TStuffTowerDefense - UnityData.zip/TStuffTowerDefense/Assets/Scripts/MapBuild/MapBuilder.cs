﻿using System.Linq;
using TStuff.Game.TowerDefense3d.lib.ContractObjects;
using TStuff.Game.TowerDefense3d.lib.Enums;
using UnityEngine;

namespace Assets.Scripts.MapBuild
{
    public class MapBuilder : MonoBehaviour
    {

        public GameObject MapBaseObject;

        public GameObject BlockPrefab;
        public GameObject GridPrefab;
        public GameObject InterestPrefab;
        public GameObject Team1BuildPrefab;
        public GameObject Team2BuildPrefab;
        public GameObject Team3BuildPrefab;
        public GameObject Team4BuildPrefab;
        public GameObject DemoMap;
        public GameObject MobWorkd;
        public GameObject TowerWorld;

        public MapDataModel Model { get; set; }
        public bool IsMapGenerated { get; set; }
        public bool IsGameCanceled { get; set; }

        // Use this for initialization
        void Start () {
		
        }
	
        // Update is called once per frame
        void Update () {
            if (!IsMapGenerated && Model != null)
            {
                SpawnMap();
                IsMapGenerated = true;
                IsGameCanceled = false;
            }
            if (IsGameCanceled)
            {
                MapDespawn();
                IsMapGenerated = false;
                Model = null;
            }
        }

      

        public void MapDespawn()
        {
            Camera.main.transform.SetParent(null);
           DemoMap.SetActive(true);
            foreach (Transform child in MapBaseObject.transform)
            {
                GameObject.Destroy(child.gameObject);
            }
        }

        public void SpawnMap()
        {

      

            Camera.main.transform.SetParent(null);
            DemoMap.SetActive(false);

            foreach (var mapTile in Model.Data)
            {
          
                if (mapTile.Type == TileType.Block)
                {
                    var block = Instantiate(BlockPrefab);
                    block.transform.SetParent(MapBaseObject.transform);
                    block.transform.SetPositionAndRotation(new Vector3(mapTile.X,1,mapTile.Y),Quaternion.identity);
                }else if (mapTile.Type == TileType.BuildTeam1 )
                {
                    var block = Instantiate(Team1BuildPrefab);
                    block.transform.SetParent(MapBaseObject.transform);
                    block.transform.SetPositionAndRotation(new Vector3(mapTile.X, 0.5f, mapTile.Y), Quaternion.identity);
                }
                else if ( mapTile.Type == TileType.BuildTeam4 )
                {
                    var block = Instantiate(Team2BuildPrefab);
                    block.transform.SetParent(MapBaseObject.transform);
                    block.transform.SetPositionAndRotation(new Vector3(mapTile.X, 0.5f, mapTile.Y), Quaternion.identity);
                }
                else if (mapTile.Type == TileType.BuildTeam3 )
                {
                    var block = Instantiate(Team3BuildPrefab);
                    block.transform.SetParent(MapBaseObject.transform);
                    block.transform.SetPositionAndRotation(new Vector3(mapTile.X, 0.5f, mapTile.Y), Quaternion.identity);
                }
                else if ( mapTile.Type == TileType.BuildTeam2)
                {
                    var block = Instantiate(Team4BuildPrefab);
                    block.transform.SetParent(MapBaseObject.transform);
                    block.transform.SetPositionAndRotation(new Vector3(mapTile.X, 0.5f, mapTile.Y), Quaternion.identity);
                }
                else if (mapTile.Type == TileType.NonBuild)
                {
                    var block = Instantiate(GridPrefab);
                    block.transform.SetParent(MapBaseObject.transform);
                    block.transform.SetPositionAndRotation(new Vector3(mapTile.X, 0.5f, mapTile.Y), Quaternion.identity);
                }
                else
                {
                    var block = Instantiate(GridPrefab);
                    block.transform.SetParent(MapBaseObject.transform);
                    block.transform.SetPositionAndRotation(new Vector3(mapTile.X, 0.5f, mapTile.Y), Quaternion.identity);
                    block = Instantiate(InterestPrefab);
                    block.transform.SetParent(MapBaseObject.transform);
                    block.transform.SetPositionAndRotation(new Vector3(mapTile.X, 0.5f, mapTile.Y), Quaternion.identity);
                }
            }
        }
    }
}
