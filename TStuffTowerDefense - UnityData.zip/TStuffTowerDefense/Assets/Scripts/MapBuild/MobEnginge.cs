﻿using TStuff.Game.TowerDefense3d.lib.ContractObjects;
using UnityEditorInternal;
using UnityEngine;

namespace Assets.Scripts.MapBuild
{
    public class MobEnginge : MonoBehaviour
    {

        public Vector3 MoveToPosition;
        public int Hp;
        public int Id;
        public int MobId;
        public int SenderTeam;
        public int TargetTeam;
        public int Status;
        public float Speed = 5f;
        public bool IsActive;
        


        private float _lastUpdate;
        private MobRenderer _renderer;
        private Transform _hpbar;
        private int _baseHp;
        private MobData _mobData;

        void Start ()
        {
            _hpbar = gameObject.transform.Find("HPBar");
        
        }
	
        // Update is called once per frame
       public void Update ()
        {
            if (!IsActive) return;

            if (MyMobState == MobState.Alive)
            {

                SetHpBar();
                RotateToPos();

                _lastUpdate += Time.deltaTime;

                //float step = Speed * Time.deltaTime;

                transform.position = Vector3.Lerp(transform.position, MoveToPosition, Speed * Time.deltaTime);

                if (_lastUpdate > 30f)
                {
                    DeactivateMob();
                }
            }
            else if(MyMobState == MobState.Goal)
            {
                DeactivateMob();
            }
            else if (MyMobState == MobState.Dead)
            {
                
            }

        }

        private void RotateToPos()
        {
            
            var targetDir = MoveToPosition - transform.position;
            float rstep = 9999 * Time.deltaTime;
            Vector3 newDir = Vector3.RotateTowards(transform.forward, targetDir, rstep, 0.0F);
            //Debug.DrawRay(transform.position, newDir, Color.red);
            var newRot = Quaternion.LookRotation(newDir);
            var angel = Quaternion.Angle(transform.rotation, newRot);
            if(angel >= 5 || angel <= -5) transform.rotation = Quaternion.LookRotation(newDir);
        }

        private void SetHpBar()
        {
            if (PreHp == Hp) return;

            var mat = _hpbar.GetComponent<Renderer>();
            var percHp = ( 100f/_baseHp) * Hp;
        
            _hpbar.localScale = new Vector3(_hpbar.localScale.x, _hpbar.localScale.y, (percHp / 100f));

            if (percHp > 75)
            {
                mat.material.color = Color.green;
            }
            else if
                (percHp > 50)
            {
                mat.material.color = Color.yellow;
            }
            else
            {
                mat.material.color = Color.red;
            }
        }

        public void DeactivateMob()
        {
            IsActive = false;
            gameObject.SetActive(false);
            _renderer.RemoveMob(this);
        }

        private void SetData(MobMovementModel moveMob)
        {
            PreHp = Hp;
            Hp = moveMob.Hp;
            MobId = moveMob.MobId;
            MoveToPosition = new Vector3(moveMob.X,0.7f,moveMob.Y);
            _lastUpdate = 0;
            Speed = moveMob.Speed;
            MyMobState = moveMob.WorldStatus;
        }

        public MobState MyMobState { get; set; }

        public int PreHp { get; set; }

        public void StartUp(MobMovementModel moveMob, MobRenderer r,MobData mData)
        {

            _mobData = mData;
            _renderer = r;
            Id = moveMob.Id;
            SetData(moveMob);
            transform.SetPositionAndRotation(MoveToPosition,Quaternion.identity);
            IsActive = true;
            _baseHp = Hp;
        }

        public void UpdateData(MobMovementModel moveMob)
        {
            SetData(moveMob);
        }
    }
}
