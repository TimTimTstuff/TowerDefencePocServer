﻿using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Game;
using TStuff.Game.TowerDefense3d.lib.ContractObjects;
using UnityEngine;

namespace Assets.Scripts.MapBuild
{
    public class TowerRenderer : MonoBehaviour {

        public GameObject TowerModel;
        public GameObject TowerParent;

        public Stack<MapTowers> TowersToBuild { get; set; }
        public Stack<MapTowers> TowersToRemove { get; set; }
        public List<TowerStateModel> TowerState { get; set; }
        public List<MapTowers> AllTowers { get; set; }
        public bool UpdateRequired { get; set; }
        
        public Dictionary<int,TowerEngine> TowerEngines { get; set; }
        private GamePlayerInfo _data;
        private bool _clearAll;

        // Use this for initialization
        void Start()
        {
            TowersToBuild = new Stack<MapTowers>();
            TowersToRemove = new Stack<MapTowers>();
            TowerEngines = new Dictionary<int, TowerEngine>();
            AllTowers = new List<MapTowers>();
            _data = GameObject.Find("GlobalEvents").GetComponent<GamePlayerInfo>();
        }

        // Update is called once per frame
        void Update()
        {

            if (_clearAll)
            {
                foreach (Transform tower in TowerParent.transform)
                {
                    GameObject.Destroy(tower.gameObject);
                }
                TowerEngines.Clear();
                TowersToBuild.Clear();
                TowersToRemove.Clear();
                AllTowers.Clear();
                _clearAll = false;
                return;
            }
            if (TowersToBuild == null) return;
            while (TowersToBuild.Count > 0)
            {
                var element = TowersToBuild.Pop();
                GameObject inst;
                var towerData = _data.DbTowers.SingleOrDefault(t => t.TowerId == element.TowerId);
                if (towerData == null)
                {
                    Debug.LogError("Cant find Towerdata for: "+element.TowerId);
                    return;
                }

                if (_data.TowerModels.ContainsKey(towerData.ClientModelId))
                {
                    inst = _data.TowerModels[towerData.ClientModelId];
                }
                else
                {
                    inst = _data.TowerModels.First().Value;
                }
                var newTower = Instantiate(inst);
                newTower.transform.SetPositionAndRotation(new Vector3(element.X,0.5f, element.Y), Quaternion.identity);
                newTower.transform.SetParent(TowerParent.transform);
                newTower.GetComponent<TowerEngine>().SetData(towerData);
                TowerEngines.Add(element.Id,newTower.GetComponent<TowerEngine>());
            }
            if (UpdateRequired && TowerState != null)
            {
                for (var i = 0; i < TowerState.Count; i++)
                {
                    var el = TowerState[i];
                    if (!TowerEngines.ContainsKey(el.Id)) return;
                    if (el.TargetId != null && el.TargetId.Length > 0)
                    {
                        try
                        {
                            TowerEngines[el.Id].Target = gameObject.GetComponent<MobRenderer>()._mobEnginges[el.TargetId[0]]
                                .gameObject;
                        }
                        catch
                        {
                            TowerEngines[el.Id].Target = null;
                        }
                    }
                    else
                    {
                        TowerEngines[el.Id].Target = null;
                    }
                
                }
                TowerState = null;
                UpdateRequired = false;
            }
        }

        public void Clear()
        {
            _clearAll = true;
        }
    }
}
