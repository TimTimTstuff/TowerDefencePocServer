﻿using TStuff.Game.TowerDefense3d.lib.ContractObjects;
using UnityEngine;

namespace Assets.Scripts.MapBuild
{
    public class TowerEngine : MonoBehaviour
    {

        public GameObject Target;
        public GameObject RotateToTarget;
        private ParticleSystem _particle;
        private TowerData _towerData;
        public float _fireTimer = 0;

        public void Start()
        {
            _particle = transform.GetComponentInChildren<ParticleSystem>();
        
        }

        public void SetData(TowerData data)
        {
            _towerData = data;
        }

        public void Update()
        {
            if(_fireTimer > 0)
                _fireTimer -= Time.deltaTime*1000;
        
        
            if (Target != null)
            {
                if (_fireTimer <= 0)
                {
                    _particle.Emit(1);
                    _fireTimer = _towerData==null?1000f:(float) _towerData.FireSpeed;
               
                }
                if (RotateToTarget != null)
                {
                    var targetDir = Target.transform.position - RotateToTarget.transform.position;
                    float step = 12 * Time.deltaTime;
                    Vector3 newDir = Vector3.RotateTowards(RotateToTarget.transform.forward, targetDir, step, 0.0F);
                    Debug.DrawRay(RotateToTarget.transform.position, newDir, Color.red);

                    RotateToTarget.transform.rotation = Quaternion.LookRotation(newDir);
                }
            }
        }
    }
}
