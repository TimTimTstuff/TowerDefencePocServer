﻿using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Game;
using TStuff.Game.TowerDefense3d.lib.ContractObjects;
using UnityEngine;

namespace Assets.Scripts.MapBuild
{
  public class MobRenderer : MonoBehaviour
  {
      public GameObject MobTemplate;
      public GameObject MobParent;
      public List<GameObject> Mobs { get; set; }
      public Dictionary<int,MobEnginge> _mobEnginges = new Dictionary<int,MobEnginge>();
      private readonly Dictionary<int,Stack<GameObject>> _mobPool = new Dictionary<int, Stack<GameObject>>();
      private GamePlayerInfo _data;
      private bool _clearAll;
      public List<MobMovementModel> MoveMobs { get; set; }
      public bool UpdateMobs { get; set; }
    

      public void Start()
      {
          Mobs = new List<GameObject>();
          _data = GameObject.Find("GlobalEvents").GetComponent<GamePlayerInfo>();
        }

        public void Update()
        {
            if (_clearAll)
            {
                foreach (Transform tower in MobParent.transform)
                {
                    GameObject.Destroy(tower.gameObject);
                }
                _mobEnginges.Clear();
                _mobPool.Clear();
                _clearAll = false;
                return;
            }

            if (!UpdateMobs || MoveMobs==null) return;
            MobMoveVersion2();
           //MobMoveVersion1();
           UpdateMobs = false;
        }

      private void MobMoveVersion2()
      {
          for (int i = 0; i < MoveMobs.Count; i++)
          {
              if (!_mobPool.ContainsKey(MoveMobs[i].MobId)) _mobPool.Add(MoveMobs[i].MobId,new Stack<GameObject>());

              var existing = _mobEnginges.ContainsKey(MoveMobs[i].Id);
              if (!existing)
              {
                  SpawnMob(MoveMobs[i]);
              }
              else
              {
                  UpdateRunMobs(MoveMobs[i],_mobEnginges[MoveMobs[i].Id]);
              }
          }
          MoveMobs = null;

            //foreach (var keyValuePair in _mobEnginges)
            //{
            //    if (keyValuePair.Value.gameObject.activeSelf)
            //    {
            //        keyValuePair.Value.UpdateMe();
            //    }
            //}
       
      }

      public void RemoveMob(MobEnginge me)
      {
          _mobEnginges.Remove(me.Id);
          _mobPool[me.MobId].Push(me.gameObject);
      }

      private void UpdateRunMobs(MobMovementModel moveMob, MobEnginge mobEnginge)
      {
         mobEnginge.UpdateData(moveMob);
        
      }

      private void SpawnMob(MobMovementModel moveMob)
      {
          GameObject inst;

          var mobData = _data.DbMobs.SingleOrDefault(t => t.MobId == moveMob.MobId);
          if (mobData == null)
          {
              Debug.LogError("Cant find Mobdata for: " + moveMob.MobId);
              return;
          }
            if (_data.MobModels.ContainsKey(mobData.ClientModelId))
          {
              inst = _data.MobModels[mobData.ClientModelId];
          }
          else
          {
              inst = _data.MobModels.First().Value;
          }
            //Exists in pool?
            GameObject goMob;
          if (_mobPool[moveMob.MobId].Count > 0)
          {
              goMob = _mobPool[moveMob.MobId].Pop();
          }
          else
          {
              goMob = Instantiate(inst);
                goMob.transform.SetParent(MobParent.transform);
          }
          goMob.SetActive(true);
         var e = goMob.GetComponent<MobEnginge>();
         _mobEnginges.Add(moveMob.Id,e);
         e.StartUp(moveMob, this,mobData);

      }

      private void MobMoveVersion1()
      {
          MoveMobs.ForEach(m =>
          {
              GameObject um = null;
              GameObject oldM = null;

              //Exists Pool Type
              if (!_mobPool.ContainsKey(1))
              {

                  _mobPool.Add(1,new Stack<GameObject>());
                 
              }

              //Has Element?
              um = Mobs.SingleOrDefault(r => r.name == (m.Id + "_mob"));
           
              
              if (um == null)
              {
                  if (_mobPool[1].Count > 0)  
                    oldM = _mobPool[1].Pop();
                  GameObject goMob;
                  if (oldM == null)
                  {
                      goMob = Instantiate(MobTemplate);
                      goMob.transform.SetParent(MobParent.transform);
                  }
                  else
                  {
                      oldM.SetActive(true);
                      goMob = oldM;
                  }
                  Mobs.Add(goMob);

                  // goMob.transform.SetParent(MobParent.transform);
                  goMob.name = m.Id + "_mob";
                  goMob.transform.SetPositionAndRotation(new Vector3(m.X, (float) 0.1, m.Y), Quaternion.identity);
              }
              else
              {
                  
                  // um.GetComponent<Renderer>().enabled = false;
                  um.transform.SetPositionAndRotation(new Vector3(m.X, 0.7f, m.Y), Quaternion.identity);
              }
          });

          var deleteMobs = Mobs.Where(a => MoveMobs.SingleOrDefault(x => x.Id + "_mob" == a.name) == null).ToList();
          
          MoveMobs = null;

          deleteMobs.ForEach(m =>
          {
             
              _mobPool[1].Push(m);
              Mobs.Remove(m);
              m.SetActive(false);
          });
      }

      public void Clear()
      {
          _clearAll = true;
      }
  }
}
