﻿using System;
using System.Collections.Generic;
using System.Linq;
using TStuff.Game.TowerDefense3d.lib.ContractObjects;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Assets.Scripts.Game
{
    public class GamePlayerInfo : MonoBehaviour
    {
        public int MyTeamId { get; set; }
        public int MyId { get; set; }
        public JoinGame PlayerInfo { get; set; }
        public Login LoginData { get; set; }
        public List<TowerRace> TowerRaces { get; set; }
        public List<MobRace> MobRaces { get; set; }
        public Dictionary<int,GameObject> TowerModels { get; set; }
        public Dictionary<int,GameObject> MobModels { get; set; }
        public Dictionary<int, List<int>> TowerToRace { get; set; }
        public Dictionary<int, List<int>> MobsToRace { get; set; }
        public List<MobData> DbMobs { get; set; }
        public List<TowerData> DbTowers { get; set; }
        public List<MobRace> DbMobRaces { get; set; }
        public List<TowerRace> DbTowerRaces { get; set; }
        public TowerRace MyTowerRace { get; set; }
        public MobRace MyMobRace { get; set; }

        [Serializable]
        public struct TowerPrefabs
        {
            public int Id;
            public GameObject Tower;
        }

        public TowerPrefabs[] towers;

        [Serializable]
        public struct MobPrefabs
        {
            public int Id;
            public GameObject Mob;
        }

        [Serializable]
        public struct SpriteRegister
        {
            public string Name;
            public Sprite Sprite;
        }

        public SpriteRegister[] Sprites;

        public MobPrefabs[] mobs;
        private RaceModels _raceModel;

        // Use this for initialization
        void Start ()
        {
            TowerModels = new Dictionary<int, GameObject>();
            MobModels = new Dictionary<int, GameObject>();
            //LoadAllPrefabs();
            foreach (var towerPrefabse in towers)
            {
                TowerModels.Add(towerPrefabse.Id,towerPrefabse.Tower);
            }
            foreach (var mobPrefabs in mobs)
            {
                MobModels.Add(mobPrefabs.Id, mobPrefabs.Mob);
            }
            towers = null;
            mobs = null;
        }
	
        // Update is called once per frame
        void Update () {
		
        }

        

        public void LoadAllPrefabs()
        {
        
            var tower = Resources.LoadAll("PreFabs/Tower");
            var mobs = Resources.LoadAll("PreFabs/Mobs");
            foreach (Object o in tower)
            {
                Debug.Log(o);
            }
            foreach (Object o in mobs)
            {
                Debug.Log(o);
            }

            // outputs:
            //  MyClip (UnityEngine.AnimationClip)
            //  MyMaterial (UnityEngine.Material)
        }

        public void SetJoinData(JoinGame incomingObject)
        {
            PlayerInfo = incomingObject;
      
            MyTeamId = incomingObject.PlayerInfo.Single(p => p.Id == MyId).Team;
        }

        public void SetLoginData(Login incomingObject)
        {
            LoginData = incomingObject;
            MyId = incomingObject.Id;
        }

        public void SetTowerMobData(RaceModels incomingObject)
        {
            _raceModel = incomingObject;
            if (_raceModel != null)
            {
                try
                {
                    DbMobs = _raceModel.Mobs.ToList();
                    DbTowers = _raceModel.Towers.ToList();
                    DbMobRaces = _raceModel.MobRaces.ToList();
                    DbTowerRaces = _raceModel.TowerRaces.ToList();
                    MobsToRace = _raceModel.MobRaces.ToDictionary(x=>x.MobRaceId,w=>
                        w.Mobs.Split(',').ToList().Select(int.Parse).ToList());
                    TowerToRace = _raceModel.TowerRaces.ToDictionary(x => x.RaceId, w =>
                        w.Towers.Split(',').ToList().Select(int.Parse).ToList());
                }
                catch (Exception ex)
                {
                    Debug.LogError(ex.Message);
                }
            }
        }


    }
}
