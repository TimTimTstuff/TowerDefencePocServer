﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Assets.Scripts.Game;
using Assets.Scripts.MapBuild;
using TStuff.Game.TowerDefense3d.lib.ContractObjects;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class MobTowerSpawnInfo : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler {
    private GameObject _spawnInfo;
    private List<GamePlayerInfo.SpriteRegister> _spriteList;
    private Text _values;
    private Image _elementImage;
    private Image _armorDmgImage;
    public MobData MobData;
    public TowerData TowerData;
    private Text _keys;


    // Use this for initialization
	void Start ()
	{
	    _spawnInfo = GameObject.Find("GlobalEvents").GetComponent<GlobalEvents>().MobTowerSpawnInfo;
	    _spriteList = GameObject.Find("GlobalEvents").GetComponent<GamePlayerInfo>().Sprites.ToList();
	    _values = _spawnInfo.transform.Find("Values").GetComponent<Text>();
	    _keys = _spawnInfo.transform.Find("MoneyInfo").GetComponent<Text>();
	    _armorDmgImage = _spawnInfo.transform.Find("ArmorDmgType").GetComponent<Image>();
	    _elementImage = _spawnInfo.transform.Find("Element").GetComponent<Image>();
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public void OnPointerEnter(PointerEventData eventData)
    {

        if (TowerData != null)
        {

            SetTextInfoTower();
            if (_spriteList.Any(s => s.Name == TowerData.DmgType + "Dmg"))
            {
                var sprite = _spriteList.Single(s => s.Name == TowerData.DmgType + "Dmg");
                _armorDmgImage.sprite = sprite.Sprite;
            }
            else
            {
                Debug.LogWarning("Cant Find Sprite: "+TowerData.DmgType+"Dmg");
            }
          
          
        }
        else if (MobData != null)
        {
            SetTextInfoMob();
            if (_spriteList.Any(s => s.Name == MobData.Armor + "Arm"))
            {
                var sprite = _spriteList.Single(s => s.Name == MobData.Armor+ "Arm");
                _armorDmgImage.sprite = sprite.Sprite;
            }
            else
            {
                Debug.LogWarning("Cant Find Sprite: " + MobData.Armor+ "Arm");
            }
        }

        _spawnInfo.SetActive(true);

    }

    private void SetTextInfoMob()
    {
        _keys.text = string.Format(
            @"{0}
{1}
{2}
{3}
{4}
{5}
{6}
",
            "Armor:", "Hp:", "Speed:", "Cost:", "Income:", "Gold d.:", "Xp d.:");
        _values.text = string.Format(
            @"{0}
{1}
{2}
{3}
{4}
{5}
{6}
",
            MobData.Armor.ToString(), MobData.Hp, MobData.Speed, MobData.Cost, MobData.AddIncome, MobData.GoldDrop,
            MobData.XpDrop);
    }

    private void SetTextInfoTower()
    {
        _keys.text = string.Format(
            @"{0}
{1}
{2}
{3}
{4}
{5}
{6}
",
            "Attack:", "Damage:", "Speed:", "Range:", "Effect:", "Element:", "Cost:");
        _values.text = string.Format(
            @"{0}
{1}
{2}
{3}
{4}
{5}
{6}
",
            TowerData.DmgType.ToString(), TowerData.DamageMin + " - " + TowerData.DamageMax,
            Math.Round(TowerData.FireSpeed / 1000, 2) + "s", TowerData.Range,
            (TowerData.Effect == null ? "None" : TowerData.Effect.Type.ToString()), "None", TowerData.GoldCost);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
       _spawnInfo.SetActive(false);
    }
}
