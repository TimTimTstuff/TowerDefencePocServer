﻿namespace Assets.Scripts.Game
{
    public enum GameStage
    {
        None,
        Initialize,
        Start,
        Menu,
        Game,
        Statistics
    }
}