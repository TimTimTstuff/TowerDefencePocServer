﻿using System;
using System.Linq;
using Assets.Scripts.Helper;
using Assets.Scripts.Network;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts.Game
{
    public class GlobalEvents : MonoBehaviour
    {
        #region Public Unity Setter
        public GameObject IntroUi;


      
        [Header("Script Elements")]
        public GameObject ServerConnection;
        public GameObject Ui;
        public GameObject MapController;
        [Header("UI Elements")]
         public GameObject IntroConnection;
        public GameObject IntroCreate;
        public GameObject IntroJoin;
        public GameObject GameUi;
        [Header("Mob and Tower Send")]
        public GameObject MobTowerSpawnInfo;
        public GameObject MobSendList;
        public GameObject MobSendButtonTemplate;
        public GameObject TowerSendList;
        public GameObject TowerSendButtonTemplate;

        #endregion

        #region Components

        private NetworkClient _nClient;
        private GameUiEvents _gameUi;
        private GamePlayerInfo _gameData;
     
        #endregion

        private GameStage _currentGameStage = GameStage.None;

        void Start ()
        {
            _nClient = ServerConnection.GetComponent<NetworkClient>();
            _gameUi = Ui.GetComponent<GameUiEvents>();
            _gameData = GetComponent<GamePlayerInfo>();
            MobTowerSpawnInfo.SetActive(false);
        }

        public void StartGame()
        {
            
            Debug.Log("GameStage is set to Start!");
         
            _currentGameStage = GameStage.Start;
        }

        public void LeaveGame()
        {
            _currentGameStage = GameStage.Initialize;
        }
	
        // Update is called once per frame
        void Update () {
            if (_currentGameStage == GameStage.None)
            {
                _currentGameStage = GameStage.Initialize;
        

                try
                {
                    _nClient.AutoLogin();
                    IntroJoin.SetActive(true);

                }
                catch (Exception ex)
                {
                    Debug.LogWarning("Cant connect: "+ex.Message);
                    IntroConnection.SetActive(true);
                }

            }
            if (_currentGameStage == GameStage.Initialize)
            {
                GameLoaded = false;
                _currentGameStage = GameStage.Menu;
                IntroUi.SetActive(true);
                GameUi.SetActive(false);
            }
            if (_currentGameStage == GameStage.Menu)
            {
                if(IntroUi.activeSelf == false)IntroUi.SetActive(true); 
            }
            if (_currentGameStage == GameStage.Start)
            {

                if (!GameLoaded)
                {
                    foreach (Transform o in TowerSendList.transform)
                    {
                        Destroy(o.gameObject);
                    }


                    foreach (Transform o in MobSendList.transform)
                    {
                        Destroy(o.gameObject);
                    }


                    _gameData.TowerToRace[_gameData.MyTowerRace.RaceId].ForEach(t =>
                    {
                        var el = GameObject.Instantiate(TowerSendButtonTemplate);
                        var tower = _gameData.DbTowers.Single(a => a.TowerId == t);
                        el.GetComponent<Button>().onClick.RemoveAllListeners();
                        el.GetComponent<Button>().onClick.AddListener(() =>
                        {
                          MapController.GetComponent<MouseSelector>().SetTowerBuild(t);
                        });
                        el.GetComponent<MobTowerSpawnInfo>().TowerData = tower;
                        el.GetComponentInChildren<Text>().text = tower.DisplayName+" "+tower.GoldCost;
                        el.transform.SetParent(TowerSendList.transform);
                    });
                    _gameData.MobsToRace[_gameData.MyMobRace.MobRaceId].ForEach(t =>
                    {
                        var mob = _gameData.DbMobs.Single(a => a.MobId == t);
                        var el = GameObject.Instantiate(MobSendButtonTemplate);
                        el.GetComponent<Button>().onClick.RemoveAllListeners();
                        el.GetComponent<MobTowerSpawnInfo>().MobData = mob;
                        el.GetComponent<Button>().onClick.AddListener(() =>
                        {
                            _nClient.SendMob(t);
                        });
                        el.GetComponentInChildren<Text>().text = mob.MobDisplayName+" "+mob.Cost;
                        el.transform.SetParent(MobSendList.transform);
                    });
                    GameLoaded = true;
                }

                GameUi.SetActive(true);
                if (IntroUi.activeSelf == true)
                {

                    IntroUi.SetActive(false);
                }
            }
        }

        public bool GameLoaded { get; set; }
    }
}