﻿using System.Collections;
using System.Collections.Generic;
using Assets.Scripts.Network;
using UnityEngine;

public class GameUiEvents : MonoBehaviour
{


    public NetworkClient _nClient;
    public GameObject GameMenu;
    public GameObject TextInfoObject;

	// Use this for initialization
	void Start ()
	{
	    _nClient = GameObject.Find("ServerConnection").GetComponent<NetworkClient>();
        TextInfoObject.SetActive(false);
	}


    public void SendMob(int id)
    {
        _nClient.SendMob(id);
    }

    public void BuildTower(int id)
    {
      //  _nClient.BuildTower(id);
    }

    public void LeaveGame(int id)
    {
        _nClient.LeaveGame();
    }

    public void CloseMenu()
    {
        GameMenu.SetActive(false);
    }

    public void OpenMenu()
    {
        GameMenu.SetActive(true);
    }

	// Update is called once per frame
	void Update () {
		
	}
}
