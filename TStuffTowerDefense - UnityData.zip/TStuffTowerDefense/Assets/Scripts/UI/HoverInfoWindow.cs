﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class HoverInfoWindow : MonoBehaviour,IPointerEnterHandler, IPointerExitHandler
{

    [TextArea(3, 10)]
    public string InfoText;
    private GameObject _hoverScript;


    // Use this for initialization
	void Start ()
	{
	    _hoverScript = GameObject.Find("UI").GetComponent<GameUiEvents>().TextInfoObject;

	}

   

    // Update is called once per frame
    void Update () {
		
	}

    public void OnPointerEnter(PointerEventData eventData)
    {
        
        Debug.Log("Hallo "+gameObject.name);
        if (InfoText != null && _hoverScript.activeSelf == false)
        {
            var mousePos = Input.mousePosition;
            mousePos.y -= 20;
            _hoverScript.transform.position = mousePos;
            _hoverScript.GetComponentInChildren<Text>().text = InfoText;
            _hoverScript.SetActive(true);
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        Debug.Log("By " + gameObject.name);
        if (_hoverScript.activeSelf)
        {
            _hoverScript.SetActive(false);
        }
    }
}
