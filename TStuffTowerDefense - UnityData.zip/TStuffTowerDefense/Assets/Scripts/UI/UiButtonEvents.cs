﻿using System;
using Assets.Scripts.Network;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts.UI
{
    public class UiButtonEvents : MonoBehaviour
    {

        public GameObject UserName;
        public GameObject ServerIp;
        public GameObject ServerPort;
  
        void Start()
        {
       
            var username = UserName.GetComponent<InputField>();
            var serverIp = ServerIp.GetComponent<InputField>();
            var port = ServerPort.GetComponent<InputField>();
            if (PlayerPrefs.GetString("name") != null)
            {
                username.text = PlayerPrefs.GetString("name");
            }
            if (PlayerPrefs.GetString("ip") != null)
            {
                serverIp.text = PlayerPrefs.GetString("ip");
            }
            if (PlayerPrefs.GetString("port") != null)
            {
                port.text = PlayerPrefs.GetString("port");
            }
        }


        public void CreateConnection()
        {
            try
            {
                var username =  GameObject.Find("Username").GetComponent<InputField>();
                var serverIp = GameObject.Find("ServerIp").GetComponent<InputField>();
                var port = GameObject.Find("ServerPort").GetComponent<InputField>();
      
                var connection = GameObject.Find("ServerConnection").GetComponent<NetLogin>();

       
                connection.SendLogin(username.text, serverIp.text, port.text);
           
           
            }
            catch(Exception ex)
            {
                Debug.Log(ex.Message);
            }

        }

   

    }
}
