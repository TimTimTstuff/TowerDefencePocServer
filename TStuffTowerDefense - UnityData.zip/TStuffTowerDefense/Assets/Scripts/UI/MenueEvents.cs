﻿using Assets.Scripts.Network;
using NetworkCommsDotNet;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts.UI
{
    public class MenueEvents : MonoBehaviour
    {
        public GameObject ConnectionPanel;
        public GameObject CreateGamePanel;
        public GameObject SearchGamePanel;
        public GameObject ServerConnection;
        public GameObject JoinedGamePanel;
        public GameObject MainMenue;
        public GameObject Settings;

        public GameObject ButtonSearchGame;
        public GameObject ButtonCreateGame;

        public bool ResetGameWindow { get; set; }

        // Use this for initialization
        void Start () {
            DisableAllMenueWindows();
       
        }

        private void DisableAllMenueWindows()
        {
            ConnectionPanel.SetActive(false);
            CreateGamePanel.SetActive(false);
            SearchGamePanel.SetActive(false);
            JoinedGamePanel.SetActive(false);
            MainMenue.SetActive(false);
            Settings.SetActive(false);
        }

        public void ShowConnection()
        {
            DisableAllMenueWindows();
            ConnectionPanel.SetActive(true);
       
        }

        public void ShowCreate()
        {
            DisableAllMenueWindows();
      
            CreateGamePanel.SetActive(true);
            ServerConnection.GetComponent<NetworkClient>().RequestMapCreateGameInfo();

        }

        public void ShowJoindedGamePanel()
        {
            DisableAllMenueWindows();
            JoinedGamePanel.SetActive(true);
        }

        public void ShowSettings()
        {
            DisableAllMenueWindows();
            Settings.SetActive(true);
        }

        public void ShowJoin()
        {
            DisableAllMenueWindows();
            SearchGamePanel.SetActive(true);
            ServerConnection.GetComponent<NetworkClient>().RequestOpenGames();
        }

        public void Exit()
        {
            var con = ServerConnection.GetComponent<NetworkClient>().Connection;
            if (con != null && con.ConnectionInfo.ConnectionState == ConnectionState.Established)
            {
                con.Dispose();
            }
            Application.Quit();
        }

        public void ShowMenue()
        {
            DisableAllMenueWindows();
            MainMenue.SetActive(true);
            var con = ServerConnection.GetComponent<NetworkClient>().Connection;
            if (con != null && con.ConnectionInfo.ConnectionState == ConnectionState.Established)
            {
                ButtonCreateGame.GetComponent<Button>().interactable = true;
                ButtonSearchGame.GetComponent<Button>().interactable = true;
            }
            else
            {
                ButtonCreateGame.GetComponent<Button>().interactable = false;
                ButtonSearchGame.GetComponent<Button>().interactable = false;
            }
        }


        // Update is called once per frame
        void Update () {
            if (ResetGameWindow)
            {
                ResetGameWindow = false;
                ShowJoin();
            }
        }

    
    }
}
