﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Assets.Scripts.Game;
using Assets.Scripts.Network;
using TStuff.Game.TowerDefense3d.lib;
using TStuff.Game.TowerDefense3d.lib.ContractObjects;
using TStuff.Game.TowerDefense3d.lib.Enums;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts.UI
{
    public class GameJoinUi : MonoBehaviour
    {


        public GameObject ButtonRefresh;
        public GameObject ContentScrollView;
        public GameObject TemplateScrollViewItem;
        public GameObject StartGameButton;
        public GameObject ContentPlayerView;
        public GameObject TemplatePlayerItem;
        public GameObject GameStartScreen;
        public GameObject RaceDropdown;
        public GameObject TowerDropDown;
        public GameObject GlobalGameData;

        private int _myTestNumber;

        public List<OpenGameInfo> OpenGameList = new List<OpenGameInfo>();
        public JoinGame JoinGameObj { get; set; }
        public bool IsGameListChanged;
        public bool IsPlayerListChanged;
        private NetworkClient _nClient;
        private Dropdown _teamDropDown;
        private Toggle _readyDropdown;
        private Dropdown _raceDropdown;
        private Dropdown _towerDropdown;
        private GamePlayerInfo _gameData
            ;


        // Use this for initialization
        void Start ()
        {
            _nClient = GameObject.Find("ServerConnection").GetComponent<NetworkClient>();
            _teamDropDown = GameStartScreen.transform.Find("Team").GetComponent<Dropdown>();
            _readyDropdown = GameStartScreen.transform.Find("Ready").GetComponent<Toggle>();
            _raceDropdown = RaceDropdown.GetComponent<Dropdown>();
            _towerDropdown = TowerDropDown.GetComponent<Dropdown>();
            _gameData = GlobalGameData.GetComponent<GamePlayerInfo>();

           
        }

        public void JoinGame(int id)
        {
            _nClient.JoinGame(id);

        }

        public void CreateGames()
        {
            var go =  GameObject.Instantiate(TemplateScrollViewItem);
            go.transform.SetParent(ContentScrollView.transform);
            go.GetComponentInChildren<Button>()
                .onClick.AddListener(() =>
                {
                    JoinGame(go.GetInstanceID());
                });
            go.SetActive(true);
            _myTestNumber++;

        }

        public void SetReady()
        {
            Debug.Log("Set Ready!");
            _nClient.Connection.SendObject(RequestNames.GameNotification,new GameNotifications{Notification = GameNotificationType.Ready,IntValue = _readyDropdown.isOn?1:0});

        }

        public void Leave()
        {
            Debug.Log("Leave!");
            _nClient.Connection.SendObject(RequestNames.GameNotification, new GameNotifications { Notification = GameNotificationType.LeaveGame });

        }

        public void ChangeTeam()
        {
         
                _nClient.Connection.SendObject(RequestNames.GameNotification,
                    new GameNotifications
                    {
                        Notification = GameNotificationType.ChangeTeam,
                        IntValue = _teamDropDown.value
                    });
            _teamDropDown.RefreshShownValue();
            
            
        }

        public void StartGame()
        {
            Debug.Log("Start Game");
            _nClient.Connection.SendObject(RequestNames.GameNotification,new GameNotifications{Notification = GameNotificationType.StartGame});
        }

        public void ChangeTowerRace()
        {
            _gameData.MyTowerRace = _gameData.DbTowerRaces[_towerDropdown.value];
            _gameData.MyMobRace = _gameData.DbMobRaces[_raceDropdown.value];
        }

        // Update is called once per frame
        void Update () {


            if (OpenGameList != null && IsGameListChanged)
            {
                if (JoinGameObj != null)
                {
                    GameStartScreen.SetActive(true);
                    return;
                }
                foreach (Transform o in ContentScrollView.transform)
                {
                    GameObject.Destroy(o.gameObject);
                }
                OpenGameList.ForEach(l =>
                {
                    var go = GameObject.Instantiate(TemplateScrollViewItem);
                    go.transform.SetParent(ContentScrollView.transform);
                    go.transform.Find("Description").GetComponent<Text>().text =
                        "Owner: " + l.Owner + " Map: " + l.MapName.MapName;
                    go.GetComponentInChildren<Button>()
                        .onClick.AddListener(() =>
                        {
                            JoinGame(l.GameId);
                        });
                    go.SetActive(true);
                });
                IsGameListChanged = false;

            
            }



            if (IsPlayerListChanged && JoinGameObj != null && JoinGameObj.PlayerInfo != null)
            {
            
                if (JoinGameObj.GameState == GameState.LoadState)
                {
                    Debug.Log("Game Starts now!");
                    GameObject.Find("GlobalEvents").GetComponent<GlobalEvents>().StartGame();
                    JoinGameObj = null;
                    OpenGameList = null;
                    IsPlayerListChanged = false;
                    return;
                }

                if (_teamDropDown.options.Count < 1)
                {
                    _teamDropDown.ClearOptions();
                    for (int i = 0; i < JoinGameObj.MapInfo.MaxPlayer; i++)
                    {
                        _teamDropDown.options.Add(new Dropdown.OptionData { text = "Team " + (i + 1) });
                    }
                    _teamDropDown.RefreshShownValue();
                    Debug.Log("Update TEams");
                }

                if (_raceDropdown.options.Count < 1)
                {
                    _gameData.DbMobRaces.ForEach(r =>
                    {
                        _raceDropdown.options.Add(new Dropdown.OptionData
                        {
                            text = r.DisplayName,

                        });

                    });
                    _gameData.DbTowerRaces.ForEach(t =>
                    {
                        _towerDropdown.options.Add(new Dropdown.OptionData
                        {
                            text = t.DisplayName
                        });

                    });
                 
                    ChangeTowerRace();
                    _towerDropdown.RefreshShownValue();
                    _raceDropdown.RefreshShownValue();
                }

                Debug.Log("Update Game Start Screen "+JoinGameObj.GameState);
                GameObject.Find("UI").GetComponent<MenueEvents>().ShowJoindedGamePanel();
                foreach (Transform o in ContentPlayerView.transform)
                {
                    GameObject.Destroy(o.gameObject);
                }
	        
           

                foreach (var player in JoinGameObj.PlayerInfo)
                {
                    var go = GameObject.Instantiate(TemplatePlayerItem);
                    go.transform.SetParent(ContentPlayerView.transform);
                    go.transform.Find("Name").GetComponent<Text>().text =
                        "Player: "+player.Name+" Team: "+player.Team+" State: "+player.State;
                    go.SetActive(true);
                }
                IsPlayerListChanged = false;
                StartGameButton.GetComponent<Button>().interactable = JoinGameObj.PlayerInfo.All(p => p.State == PlayerState.Ready);
            }
        }
    }
}
