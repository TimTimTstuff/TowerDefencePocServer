﻿using Assets.Scripts.Game;
using TStuff.Game.TowerDefense3d.lib.ContractObjects;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts.UI
{
    public class GameUiInfoUpdater : MonoBehaviour
    {

        [Header("Top Info")]
        public GameObject Money;
        public GameObject Income;
        public GameObject IncomeTimer;
        public GameObject Mobs;

        [Header("Team Info")]
        public GameObject Team1;
        public GameObject Team2;
        public GameObject Team3;
        public GameObject Team4;

        public GameInfoData Info { get; set; }
        public bool IsUpdateNeeded = false;
        private GamePlayerInfo _info;

        // Use this for initialization
        void Start () {
            _info = GameObject.Find("GlobalEvents").GetComponent<GamePlayerInfo>();
        }
	
        // Update is called once per frame
        void Update()
        {
            if (!IsUpdateNeeded) return;

            IncomeTimer.GetComponentInChildren<Text>().text = Info.IncomeTimer.ToString();
            Income.GetComponentInChildren<Text>().text = Info.OwneIncome.ToString();
            Money.GetComponentInChildren<Text>().text = Info.OwneMoney.ToString();
            Mobs.GetComponentInChildren<Text>().text = Info.MobsOnWorld.ToString();

            if (Info.HPTeam1 == -1)
            {
                if (Team1.activeSelf)
                    Team1.SetActive(false);
            }
            else
            {
                if (!Team1.activeSelf)
                    Team1.SetActive(false);
                Team1.gameObject.GetComponentInChildren<Text>().text =
                    Info.HPTeam1 + " " + (Info.HighestIncome == 0 ? "HI" : "") + " " +
                    (_info.MyTeamId == 0 ? Info.TeamIncomeTotal.ToString() : "");
            }
            if (Info.HPTeam2 == -1)
            {
                if (Team2.activeSelf)
                    Team2.SetActive(false);
            }
            else
            {
                if (!Team2.activeSelf)
                    Team2.SetActive(false);
                Team2.gameObject.GetComponentInChildren<Text>().text =
                    Info.HPTeam2 + " " + (Info.HighestIncome == 1 ? "HI" : "") + " " +
                    (_info.MyTeamId == 1 ? Info.TeamIncomeTotal.ToString() : "");
            }
            if (Info.HPTeam3 == -1)
            {
                if (Team3.activeSelf)
                    Team3.SetActive(false);
            }
            else
            {
                if (!Team3.activeSelf)
                    Team3.SetActive(false);
                Team3.gameObject.GetComponentInChildren<Text>().text =
                    Info.HPTeam3 + " " + (Info.HighestIncome == 2 ? "HI" : "") + " " +
                    (_info.MyTeamId == 2 ? Info.TeamIncomeTotal.ToString() : "");
            }
            if (Info.HPTeam4 == -1)
            {
                if (Team4.activeSelf)
                    Team4.SetActive(false);
            }
            else
            {
                if (!Team4.activeSelf)
                    Team4.SetActive(false);
                Team4.gameObject.GetComponentInChildren<Text>().text =
                    Info.HPTeam4 + " " + (Info.HighestIncome == 3 ? "HI" : "") + " " +
                    (_info.MyTeamId == 3 ? Info.TeamIncomeTotal.ToString() : "");
            }
        }
    }
}

