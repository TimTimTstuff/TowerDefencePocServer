﻿using System.Linq;
using Assets.Scripts.Network;
using TStuff.Game.TowerDefense3d.lib.ContractObjects;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts.UI
{
    public class GameCreateUi : MonoBehaviour {


        public MapSelectList MapList { get; set; }
        public GameObject DropDownElement;
        public GameObject DescriptionText;
        private NetworkClient _nClient;

        [Header("Settings Input")]
        public GameObject Hp;
        public GameObject StartGold;
        public GameObject StartIncome;
        public GameObject IncomeTime;
        public GameObject MaxEnemsPt;
        public GameObject SpawnDelay;
        public GameObject MaxEnemys;
        public GameObject TimeToStart;
        public bool MapListChanged { get; set; }

        // Use this for initialization
        void Start ()
        {
            _nClient = GameObject.Find("ServerConnection").GetComponent<NetworkClient>();
        }

        private void AddMapInfo()
        {
            if (this.MapList == null || this.MapList.Maps == null)
            {
                return;
            }

            var dropdown = DropDownElement.GetComponent<Dropdown>();
            dropdown.value = 0;
            dropdown.ClearOptions();
            dropdown.AddOptions(MapList.Maps.OrderBy(a=>a.Id).Select(a=>a.Id+" "+a.MapName).ToList());
            DropDownMapSelectChanged();
        }

        public void DropDownMapSelectChanged()
        {
            var description = DescriptionText.GetComponent<Text>();
            description.text = "Map Description";
            var selected = DropDownElement.GetComponent<Dropdown>().value;
            var selectedMap = MapList.Maps[selected];
            description.text += "\r\nName: " + selectedMap.MapName + "\r\nPlayer: " + selectedMap.MaxPlayer
                                + "\r\nSize: " + selectedMap.Width + " * "+selectedMap.Height+"\r\n"+selectedMap.Description;

        }

        public void CreateGame()
        {
            _nClient.CreateGame(new GameSettings
            {
                Hp = int.Parse(Hp.GetComponent<InputField>().text),
                IncomeTime = int.Parse(IncomeTime.GetComponent<InputField>().text),
                MaxMobs = int.Parse(MaxEnemys.GetComponent<InputField>().text),
                MaxMobsPerTeam = int.Parse(MaxEnemsPt.GetComponent<InputField>().text),
                MobSpawnDelay = int.Parse(SpawnDelay.GetComponent<InputField>().text),
                StartGold = int.Parse(StartGold.GetComponent<InputField>().text),
                StartIncome = int.Parse(StartIncome.GetComponent<InputField>().text),
                TimeBeforeMobs = int.Parse(TimeToStart.GetComponent<InputField>().text),
                MapId = DropDownElement.GetComponent<Dropdown>().value
            });
        }

    

        // Update is called once per frame
        void Update () {
            if (MapList != null && MapList.Maps != null && MapList.Maps.Length > 0 && MapListChanged)
            {
                DescriptionText.GetComponent<Text>().text = "Map Description";
                AddMapInfo();
                MapListChanged = false;
            }		
        }
    }
}
