﻿using System.Collections.Generic;
using TStuff.Game.TowerDefense3d.lib.ContractObjects;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts.UI
{
    public class GeneralUi : MonoBehaviour
    {
        private int _messageId = 0;
        public Queue<ClientMessage> Messages { get; set; }
        public bool ResetGameWindow { get; set; }

        public GameObject MessageTemplate;

        // Use this for initialization
        void Start () {
            Messages = new Queue<ClientMessage>();
        }
	
        // Update is called once per frame
        void Update () {
            if (Messages.Count > 0)
            {
                ShowMessage();
            }

	  
        }

        public void ShowMessage()
        {
            var nextMessage =  Messages.Dequeue();
            nextMessage.id = _messageId;
            var obj = GameObject.Instantiate(MessageTemplate);
            obj.transform.GetChild(1).GetComponent<Text>().text = nextMessage.Title;
            obj.transform.GetChild(2).GetComponent<Text>().text = nextMessage.Message;
            obj.transform.GetChild(3).GetComponent<Button>().onClick.AddListener(() =>
            {
                GameObject.Destroy(obj);
            });

            _messageId++;
        }

        public void CloseMessage(int id)
        {
        
        }
    }
}
